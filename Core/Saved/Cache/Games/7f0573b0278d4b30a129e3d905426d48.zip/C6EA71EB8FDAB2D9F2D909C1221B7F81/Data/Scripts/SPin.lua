local bullet = script.parent

local spinRotation = Rotation.New(2000, 0, 0)

bullet:RotateContinuous(spinRotation)